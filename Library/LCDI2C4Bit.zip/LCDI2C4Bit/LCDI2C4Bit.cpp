#include "LCDI2C4Bit.h"
#include <Wire.h>
#include <inttypes.h>

#if defined(ARDUINO) && (ARDUINO >= 100) 
#include "Arduino.h"
#else
#include "WPrograms.h"
#endif

//command bytes for LCD
#define CMD_CLR 0x01
#define CMD_RIGHT 0x1C
#define CMD_LEFT 0x18
#define CMD_HOME 0x02

//stuff the library user might call---------------------------------

//constructor.  num_lines must be 1 or 2, currently.

byte dataPlusMask = 0; // TODO!!!

LCDI2C4Bit::LCDI2C4Bit( int devI2CAddress, int num_lines, int lcdwidth) {
  myNumLines = num_lines;
  myWidth = lcdwidth;
  int newAddy = devI2CAddress;
  if (devI2CAddress != 0xA7) {
	newAddy = devI2CAddress | 0x80;
  }
    myAddress = newAddy;
}

void SetMCPReg( byte deviceAddr, byte reg, byte val ) {
  Wire.beginTransmission(deviceAddr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

void SendToLCD( byte deviceAddr, byte data ) {
  data |= dataPlusMask;
  SetMCPReg(deviceAddr,0x0A,data);
  data ^= 0x80; // E
  delayMicroseconds(1);
  SetMCPReg(deviceAddr,0x0A,data);
  data ^= 0x80; // E
  delayMicroseconds(1);
  SetMCPReg(deviceAddr,0x0A,data);
  delay(1);

}

void WriteLCDByte( byte deviceAddr, byte bdata ) {
  SendToLCD(deviceAddr,bdata >> 4);
  SendToLCD(deviceAddr,bdata & 0x0F);
}

void LCDI2C4Bit::init( void ) {
  Wire.begin();
  dataPlusMask = 0; // initial: 0
  SetMCPReg(myAddress,0x05,0x0C); // set CONFREG (0x05) to 0
  SetMCPReg(myAddress,0x00,0x00); // set IOREG (0x00) to 0
  //
  delay(50);
  SendToLCD(myAddress,0x03); 
  delay(5);
  SendToLCD(myAddress,0x03);
  delayMicroseconds(100);
  SendToLCD(myAddress,0x03);
  delay(5);
  SendToLCD(myAddress,0x02);
  WriteLCDByte(myAddress,0x28);
  WriteLCDByte(myAddress,0x08);
  WriteLCDByte(myAddress,0x0C); // turn on, cursor off, no blinking
  delayMicroseconds(60);
  WriteLCDByte(myAddress,0x01); // clear display
  delay(3);  
}

void LCDI2C4Bit::home()
{
  commandWrite(CMD_HOME);// set cursor position to zero
  delayMicroseconds(2000);  // this command takes a long time!
}

// Turn the display on/off (quickly)
void LCDI2C4Bit::display(bool state) {
	if (!state) {
		_displaycontrol &= ~LCD_DISPLAYON;
	}
	else
	{
	_displaycontrol |= LCD_DISPLAYON;
	}
	commandWrite(LCD_DISPLAYCONTROL | _displaycontrol);
}

void LCDI2C4Bit::backLight( bool turnOn ) {
  dataPlusMask |= 0x40; // Lights mask
  if (!turnOn) dataPlusMask ^= 0x40;
  SetMCPReg(myAddress,0x0A,dataPlusMask);  
}

// These commands scroll the display without changing the RAM
void LCDI2C4Bit::scrollDisplayLeft(void) {
	commandWrite(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}

void LCDI2C4Bit::scrollDisplayRight(void) {
	commandWrite(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

#if ARDUINO >= 100
inline size_t LCDI2C4Bit::write(uint8_t value) {
  doWrite(value);
  return 1;
}
#else
inline void LCDI2C4Bit::write(uint8_t value) {
  doWrite(value);
}
#endif

void LCDI2C4Bit::doWrite( uint8_t value ) {
  dataPlusMask |= 0x10; // RS
  WriteLCDByte(myAddress,(byte)value);
  dataPlusMask ^= 0x10; // RS
}
float LCDI2C4Bit::libVersion() {
return 1.1;
}
/*
void LCDI2C4Bit::print( int i){
  char tmp[20];
  sprintf(tmp,"%1d",(int)i);
  print(tmp);
}

void LCDI2C4Bit::print(long i){
  char tmp[20];
  sprintf(tmp,"%1d",(long)i);
  print(tmp);
}

void LCDI2C4Bit::print(unsigned long i){
  char tmp[20];
  sprintf(tmp,"%1d",(unsigned long)i);
  print(tmp);
}

void LCDI2C4Bit::print( float f){
char tmp[20];
  sprintf(tmp,"%1d",(int)f);
  print(tmp);
  print(".");
  int temp = (f - (int)f) * 100;
  sprintf(tmp,"%02d",abs(temp) );
  print(tmp);
  
}

void LCDI2C4Bit::print( char value[] ) {
  for ( char *p = value; *p != 0; p++ ) 
    doWrite(*p);
}
*/
void LCDI2C4Bit::clear() {
  commandWrite(CMD_CLR);
}

void LCDI2C4Bit::cursorTo(int line_num, int x) {
  commandWrite(CMD_HOME);
  int targetPos = x + (line_num * myWidth);
  for ( int i = 0; i < targetPos; i++)
    commandWrite(0x14);
}

void LCDI2C4Bit::setCursor(int col, int row){
	int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
	if ( row > myNumLines ) {
		row = myNumLines-1;    // we count rows starting w/0
	}
	commandWrite(LCD_SETDDRAMADDR | (col + row_offsets[row]));
}

void LCDI2C4Bit::commandWrite( int command ) {
  // RS - leave low
  WriteLCDByte(myAddress,command);
  delay(1);
}

void LCDI2C4Bit::createChar(uint8_t slot, uint8_t bitmask[8])
{
	//64 = write CGRAM address
	//slot<<3 = 3 bit (8 possible) cust. char. address
	commandWrite(LCD_SETCGRAMADDR | (slot << 3));

	//write the character to CGRAM
	dataPlusMask |= 0x10;
	commandWrite(bitmask[0]);
	commandWrite(bitmask[1]);
	commandWrite(bitmask[2]);
	commandWrite(bitmask[3]);
	commandWrite(bitmask[4]);
	commandWrite(bitmask[5]);
	commandWrite(bitmask[6]);
	commandWrite(bitmask[7]);
	dataPlusMask ^= 0x10;

	//set DDRAM address to make sure next write command is to DDRAM instead of CGRAM
	//this will trash your cursor position, but prevent you from accidentally overwriting custom characters
	commandWrite(LCD_SETDDRAMADDR);
}

// Alias functions

void LCDI2C4Bit::begin(){
	init();
}
