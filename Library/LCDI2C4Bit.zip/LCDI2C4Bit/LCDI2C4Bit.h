#ifndef LCDI2C4Bit_h
#define LCDI2C4Bit_h

#include <inttypes.h>
#include "Print.h"

// flags for display on/off control
#define LCD_DISPLAYON 0x04
#define LCD_DISPLAYOFF 0x00
#define LCD_DISPLAYCONTROL 0x08

// flags for display/cursor shift
#define LCD_DISPLAYMOVE 0x08
#define LCD_CURSORMOVE 0x00
#define LCD_MOVERIGHT 0x04
#define LCD_MOVELEFT 0x00

// commands
#define LCD_CLEARDISPLAY 0x01
#define LCD_RETURNHOME 0x02
#define LCD_ENTRYMODESET 0x04
#define LCD_DISPLAYCONTROL 0x08
#define LCD_CURSORSHIFT 0x10
#define LCD_FUNCTIONSET 0x20
#define LCD_SETCGRAMADDR 0x40
#define LCD_SETDDRAMADDR 0x80

// IMPORTANT! Wire. must have a begin() before calling init()

class LCDI2C4Bit : public Print {
public:
  LCDI2C4Bit(int devI2CAddress, int num_lines, int lcdwidth);
  void commandWrite(int command);
  void init();
  void begin();
//  void doWrite(uint8_t);// used for the custom chars
  void clear();
  void home();
  void backLight(bool);
  void setCursor(int, int);
  void display(bool);
  void scrollDisplayLeft();
  void scrollDisplayRight();
  void createChar(uint8_t, uint8_t * );
  float libVersion();

#if ARDUINO >= 100
  virtual size_t write(uint8_t);
#else
  virtual void write(uint8_t);
#endif

  //non-core---------------
  void cursorTo(int line_num, int x);
  //void leftScroll(int chars, int delay_time);
  //end of non-core--------

  //4bit only, therefore ideally private but may be needed by user
  //void commandWriteNibble(int nibble);

private:
  //void pulseEnablePin();
  //void pushNibble(int nibble);
  //void pushByte(int value);
  void doWrite(uint8_t);// used for the custom chars
  int myNumLines;
  int myWidth;
  int myAddress;
  uint8_t _displaycontrol;
};
#endif